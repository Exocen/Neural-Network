class Synapse(
  var weight: Double,
  parent: ActorRef,
  child: ActorRef) extends Actor {

  def demo_formula(v: Double): Double = {
    val oldw = weight
    weight = weight + (v / 10)
    if (weight < 0) weight = 0
    log.info("Weight: " + oldw + " => " + weight)
    v - 1
  }

  def receive = {
    case PreSynapticSpike(v: Double) =>
      child ! PreSynapticSpike(demo_formula(v))

    case InformNeurons =>
      child ! ImYourFather(self)
      parent ! ImYourChild(self)
      sender ! InformNeurons_ack

    case takeWeight(w :Double) => weight = w + weight
  }
}
