package fr.lifl.emeraude.n2s3.actors

import akka.actor._
import akka.event.Logging
import fr.lifl.emeraude.n2s3.actors.messages._

/**
 * Neurons are the "brain" of the simulator, they will compute and send spikes.
 *
 * @constructor create a new Neuron in a form of an actor with a layer, its parents,
 * its childs and a threshold.
 * @param layer in which the neuron is
 * @param parents sequence of synapses' references, for all "parent-synapse".
 * @param childs sequence of synapses' references, for all "child-synapse".
 * @param threshold the trigger value for the neurons.
 *
 * @author wgouzer & qbailleul
 */
class Neuron(
  layer: Int,
  var parents: Seq[ActorRef], // actor ref of synapse
  var childs: Seq[ActorRef], // actor ref of synapse
  threshold: Double) extends Actor {

  val log = Logging(context.system, this)

  def setParents(p: Seq[ActorRef]) {
    parents = p
  }

  def setChilds(c: Seq[ActorRef]) {
    childs = c
  }

  def receive = {
    case PreSynapticSpike(v: Double) => {

      if (v > threshold) {
        log.info("[Neuron] PreSynapticSpike (Pass)")
        childs map { w => w ! PreSynapticSpike(v)}
      } else {
        log.info("[Neuron] PreSynapticSpike (Block)")
      }

    }

    case PostSynapticSpike =>
      log.info("[Neuron] PostSynapticSpike")

    case ImYourFather(father: ActorRef) =>
      parents = parents :+ father

    case ImYourChild(child: ActorRef) =>
      childs = childs :+ child

    case Welcome =>
      childs foreach { w => println(w.toString) }

    case _ => throw new Exception(
      "Neuron receive a unknown message, don't know what to do"
    )
  }

}
