package fr.lifl.emeraude.n2s3

/**
  * Contains the actors representations and messages.
  * @author wgouzer & qbailleul
  */
package object actors {

}
