package fr.lifl.emeraude.n2s3.actors

import akka.actor._
import akka.event.Logging
import fr.lifl.emeraude.n2s3.actors.messages._

 /**
 * TODO doc
 * @author wgouzer & qbailleul
 */

class Counter(
 var synapses:Seq[ActorRef]
) extends Actor{

var nbMessage=0
val thMessage=5
var actives:Seq[ActorRef]=Seq()

 def receive={
     case addMessage(a: ActorRef) =>
 nbMessage=nbMessage+1
 this.actives=this.actives:+a
 if (nbMessage%thMessage==0){printf("bouya")}

     case _ => throw new Exception(
"Counter receive a unknown message, don't know what to do")
}
}