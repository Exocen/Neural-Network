class Neuron(
  layer: Int,
  var parents: Seq[ActorRef],
  var childs: Seq[ActorRef],
  threshold: Double) extends Actor {

  def receive = {
    case PreSynapticSpike(v: Double) =>
      if (v > threshold) {
        log.info("[Neuron] PreSynapticSpike (Pass)")
        childs map { w => w ! PreSynapticSpike(v)}
      } else {
        log.info("[Neuron] PreSynapticSpike (Block)")
      }

    case PostSynapticSpike =>
      log.info("[Neuron] PostSynapticSpike")

    case ImYourFather(father: ActorRef) =>
      parents = parents :+ father

    case ImYourChild(child: ActorRef) =>
      childs = childs :+ child
  }
}
