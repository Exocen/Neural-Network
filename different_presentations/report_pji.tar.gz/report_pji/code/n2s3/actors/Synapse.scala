package fr.lifl.emeraude.n2s3.actors

import akka.actor._
import akka.event.Logging
import fr.lifl.emeraude.n2s3.actors.messages._

/**
  * Synapses are the link between two Neurons.
  *
  * @constructor create a new Synapse in a form of an actor with a weight, a parent
  * and a child
  * @param weight mechanism for reinforcing or deprecating a link (synapse)
  * @param parent the "parent-neuron" connected with this synapse
  * @param child the "child-neuron" connected with this synapse
  *
  * @author wgouzer & qbailleul
  */
class Synapse(
  var weight: Double, // next version will no longer need this variable

  parent: ActorRef,
  child: ActorRef) extends Actor {

  val log = Logging(context.system, this)

  def compute_spike() {
    // given by mahyar
  }

  /**
    * a formula to test the network
    */

  def demo_formula(v: Double): Double = {
    val oldw = weight
    weight = weight + (v / 10)
    if (weight < 0) weight = 0
    log.info("Weight: " + oldw + " => " + weight)
    v - 1
  }

  def receive = {
    case PreSynapticSpike(v: Double) =>
      child ! PreSynapticSpike(demo_formula(v))

    case PostSynapticSpike => // not used yet

    case InformNeurons =>
      child ! ImYourFather(self)
      parent ! ImYourChild(self)
      sender ! InformNeurons_ack

    case Welcome => // debug purposes

    case takeWeight(w :Double) => weight = w + weight

    case _ => throw new Exception(
      "Synapse receive a unknown message, don't know what to do"
    )
  }

}
