package fr.lifl.emeraude.n2s3.actors

import akka.actor._

/**
  * Represents the messages that Neurons and Synapses will send to each other.
  * @author wgouzer & qbailleul
  */
object messages { // abstract class "Spike"

  /**
    * Typical hello world type message, it isn't useful for real world application,
    * it's here for debug and test purposes
    **/
  case class Welcome

  /**
    * Used for discovering the network, it'll allow the synapses to send messages
    * to the neurons they're connected to in order to let him update its
    * sequences (parents & childs).
    **/
  case class InformNeurons

  /**
    * Used for discovering the network, it'll allow the neurons to acknowledge
    * the reception of the message (from the synapses)
    **/
  case class InformNeurons_ack

  /**
    * Tell the neuron connected to this synapse : "this synapse is your father"
    * @param neuron for which the synapse is the father
    **/
  case class ImYourFather (neuron: ActorRef) // tell the neuron you're its father

  /**
    * Tell the neuron connected to this synapse : "this synapse is your child"
    * @param neuron for which the synapse is the child
    **/
  case class ImYourChild (neuron: ActorRef) // tell the neuron you're its child

  /**
    * Simulate a pre-synaptic spike, a simple spike before all the computing
    * done on it
    **/
  case class PreSynapticSpike (v: Double) // spikeF (forward)

  /**
    * Simulate a post-synaptic spike, a simple spike altered by the computing
    * done on it
    **/
  case class PostSynapticSpike // spikeB (backward)

  /**
    Those two messages (addMessage, takeWeight) are present just for "demoing"
    the simulation to people
    */
  case class addMessage(immune :ActorRef)
  case class takeWeight(w: Double)
}
