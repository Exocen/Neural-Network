class Network(
  threshold: Int,
  nbNeuronPerLayer: Seq[Int],
  edges: Option[Seq[(Int, Int)]] = None) {

  def createNeurons() : Array[(ActorRef, Int)] = {
    val neuroRefs = new Array[(ActorRef, Int)](_nbNeuron)
    var ind = 0

    for (i<-0 until nbNeuronPerLayer.length; j<-0 until nbNeuronPerLayer(i)) {
      neuroRefs(ind) = (system.actorOf(Props(new Neuron(i, Seq(), Seq(), threshold))), i)
      ind += 1
    } return neuroRefs
  }

  def createFullConnection(neuroRefs: Array[(ActorRef, Int)]) : Seq[ActorRef] = {
    val rand = new Random()
    var arefs = Seq.empty[ActorRef]

    for (i<-0 until _nbNeuron; j<-0 until _nbNeuron) {
      if (i != j && (neuroRefs(j)._2 - neuroRefs(i)._2) == 1) {
        arefs = arefs :+ system.actorOf(Props(new Synapse(rand.nextDouble()*10, neuroRefs(i)._1, neuroRefs(j)._1)))
      }
    } return arefs
  }

  def createManualConnection(neuroRefs: Array[(ActorRef, Int)], edges: Seq[(Int, Int)]) : Seq[ActorRef] = {
    val rand = new Random()
    var arefs = Seq.empty[ActorRef]

    edges map { w =>
      if ((neuroRefs(w._1)._2 - neuroRefs(w._2)._2) == 1) {
        arefs = arefs :+ system.actorOf(Props(new Synapse(rand.nextDouble(), neuroRefs(w._1)._1, neuroRefs(w._2)._1)))
      }
    } return arefs
  }

  def reportAndInformNeurons(synapRefs: Seq[ActorRef]) : Unit = {
    implicit val timeout = Timeout(Duration(60, "seconds"))
    synapRefs map { w => Await.result(w ? InformNeurons, Duration(300, "millis")) }
  }
}
