package fr.lifl.emeraude.n2s3

/**
  * Instanciate the neuronal network with akka's actors.
  * @author wgouzer & qbailleul
  */
object Main {

  def usage() {
    println("\nUsage: [VM] [PROGRAM] [OPTION]")
    println("\t e.g. java -jar n2s3.jar")
    println("\nAvailable options :")
    println("\t--debug")
    println("\t--verbose\n")
  }

  def main(args: Array[String]) = {
    if (args.length < 2) {
      usage
      sys.error("Missing arguments")
    }

    // instanciate the graph
    val nbNeuronPerLayer = Seq(1,2,2,3) // args(0)
    val threshold = 8                   // args(1)
    val net = new Network(threshold, nbNeuronPerLayer)
    net.input(10.0)

  }

}
