package fr.lifl.emeraude.n2s3

import akka.actor._
import akka.routing._
import akka.pattern.ask
import akka.util.Timeout

import scala.math
import scala.util.Random
import scala.concurrent.duration._
import scala.concurrent._

import fr.lifl.emeraude.n2s3.actors.{ Neuron, Synapse }
import fr.lifl.emeraude.n2s3.actors.messages.{ InformNeurons, PreSynapticSpike, Welcome }

/**
  * Create the neuronal network with a threshold, the number of neuron per layer  <br>
  * and the edges (synapses) between neurons
  *
  * @constructor Network in a form of actors inside a tree/graph.
  * @param threshold is the neurons's trigger value for propagating spikes.
  * @param nbNeuronPerLayer is the number of neurons in a layer. Conveniently,
  * the number of elements also represents the number of layer. <br>
  * The following example will produce 3 layers, the first and second will have 4
  * neurons and the last one 2 neurons :
  * {{{
  *    Seq(4,4,2)
  * }}} <br>
  * @param edges are the synapses in the network, which is a Seq of a couple of Integers,
  * like this (FromNeuron1, ToNeuron2). <br>
  * The following example will produce three oriented edges 1->2, 1->3 and 2->3 :
  * {{{
  *    Seq((1,2), (1,3), (2,3))
  * }}}
  * @author wgouzer & qbailleul
  */
class Network(
  threshold: Int,
  nbNeuronPerLayer: Seq[Int],
  edges: Option[Seq[(Int, Int)]] = None) {

  /**
    * Total number of neurons in this network, it's global for avoiding the re-computing
    * everytime a function needs it (at least 2-3 times in this code).
    **/
  lazy val _nbNeuron = nbNeuronPerLayer.sum

  /**
    * Creates all the needed neurons.
    * @return an array of couple : neurons' references and layer.
    */
  def createNeurons() : Array[(ActorRef, Int)] = {
    val neuroRefs = new Array[(ActorRef, Int)](_nbNeuron)
    var ind = 0

    // create layer with x neurons into each layer
    for (
      i <- 0 until nbNeuronPerLayer.length;
      j <- 0 until nbNeuronPerLayer(i)
    ) {
      neuroRefs(ind) = (system.actorOf(Props(
        new Neuron(i, Seq(), Seq(), threshold))), i)
      ind += 1
    }

    neuroRefs
  }

  /**
    * Create the links (synapses) between neurons.
    * @param neuroRefs the array that contains the couples of neurons' references and their layer.
    * @return the references of all the synapses created.
    */
  def createSynapses(neuroRefs: Array[(ActorRef, Int)]) : Seq[ActorRef] = {
    // # maximum of edges in a graph =>  n * (n-1) / 2
    edges match {
      case None => createFullConnection(neuroRefs)
      case Some(t) => createManualConnection(neuroRefs, t)
    }
  }

  /**
    * Connects each neuron on a higher layer to
    * every neuron in its inferior layer.
    * @param neuroRefs the array that contains the couples of neurons' references and their layer.
    * @return the references of all the synapses created.
    */
  def createFullConnection(neuroRefs: Array[(ActorRef, Int)]) : Seq[ActorRef] = {
    val rand = new Random()
    var arefs = Seq.empty[ActorRef]

    for (
      i<-0 until _nbNeuron;
      j<-0 until _nbNeuron
    ) {

      if (i != j && (neuroRefs(j)._2 - neuroRefs(i)._2) == 1) {
        arefs = arefs :+ system.actorOf(Props(
          new Synapse(rand.nextDouble()*10, neuroRefs(i)._1, neuroRefs(j)._1)))
      }
    }

    arefs
  }

  /**
    * Connects manually the neurons with synapses. It is done through the constructor.
    * param edges in [[fr.lifl.emeraude.n2s3.Network]].
    * @param neuroRefs the array that contains all the couples of neurons' references and their layer.
    * @param edges represents the connections between two neurons (synapses).
    * @return the references of all the synapses created.
    */
  def createManualConnection(neuroRefs: Array[(ActorRef, Int)], edges: Seq[(Int, Int)]) : Seq[ActorRef] = {
    val rand = new Random()
    var arefs = Seq.empty[ActorRef]

    edges map { // w is a couple of neurons' references
      w =>
      // checks if the layers are connected with +/- 1 of difference
      if ((neuroRefs(w._1)._2 - neuroRefs(w._2)._2) == 1) {
        arefs = arefs :+ system.actorOf(Props(
          new Synapse(rand.nextDouble(), neuroRefs(w._1)._1, neuroRefs(w._2)._1)))
      }
    }

    arefs
  }

  /**
    * Makes all the synapses send messages to their neurons
    * in order to inform them about the topology of the network.
    * @param synapRefs array that contains all the synapses' references.
    */
  def reportAndInformNeurons(synapRefs: Seq[ActorRef]) : Unit = {
    implicit val timeout = Timeout(Duration(60, "seconds"))

    synapRefs map { w =>
      Await.result(w ? InformNeurons, Duration(300, "millis"))
    }

  }

  /** create a new actor system with the specific name "Neuronal-network" */

  implicit val system = ActorSystem("Neuronal-network")


  /** create an Array of couple for all the neurons' references and their associated layers */
  val neuronsActorRef = createNeurons()

  /** create a Sequence of all the synapses' references */
  val synapsesActorRef = createSynapses(neuronsActorRef)

  /** tells the neurons about their new friends : synapses (edges of the graph) */
  reportAndInformNeurons(synapsesActorRef)

  /**
    * Send a message to the first Neuron in the first layer
    * @param v spike (that's the message)
    **/
  def input(v: Double) {
    for ( i<-0 until _nbNeuron) {
      if (neuronsActorRef(i)._2 == 0) { neuronsActorRef(i)._1 ! PreSynapticSpike(v)}
    }
  }

}
