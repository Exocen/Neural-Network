def main(args: Array[String]) = {
  if (args.length < 2) {
    usage
    sys.error("Missing arguments")
  }

  val nbNeuronPerLayer = Seq(1,2,2,3)
  val threshold = 8
  val net = new Network(threshold, nbNeuronPerLayer)
  net.input(10.0)
}
