package fr.lifl.emeraude

import akka.actor._

/**
  * Main package, create actors (neurons, synapses) and instanciate the whole neuronal network
  * @author wgouzer & qbailleul
  */
package object n2s3 {

}
