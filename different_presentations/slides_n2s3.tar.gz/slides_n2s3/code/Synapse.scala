abstract class Synapse(
  pre: ActorRef,
  post: ActorRef
) extends Actor { ... }
