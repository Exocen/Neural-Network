trait Spike
