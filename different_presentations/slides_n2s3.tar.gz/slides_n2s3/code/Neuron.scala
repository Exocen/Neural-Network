abstract class Neuron(
  layer: Int,
  var inputs: Seq[ActorRef] = Seq(),
  var outputs: Seq[ActorRef] = Seq()
) extends Actor { ... }
