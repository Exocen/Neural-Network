val nbNeuronPerLayer = Seq(5, 2, 3, 1)
val threshold = 8

val net = new NetworkDefault(nbNeuronPerLayer, threshold)
// val net = new NetworkPji(nbNeuronPerLayer, threshold)
// val net = new Demo1(nbNeuronPerLayer, threshold)

net.initiateNetwork()
net.firingSpikes()
